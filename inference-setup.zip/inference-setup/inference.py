import argparse
import pandas as pd
from PIL import Image
from tqdm import tqdm
import torch
from transformers import BlipProcessor, BlipForQuestionAnswering
import os
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from bert_score import score as bert_score

def compute_bleu(reference, hypothesis):
    reference = [reference.lower().split()]
    hypothesis = hypothesis.lower().split()
    smoothie = SmoothingFunction().method4
    return sentence_bleu(reference, hypothesis, smoothing_function=smoothie)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image_dir', type=str, required=True, help='Root folder containing images')
    parser.add_argument('--csv_path', type=str, required=True, help='CSV file with image paths and questions')
    args = parser.parse_args()

    # Load CSV
    df = pd.read_csv(args.csv_path)

    # Setup device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Load processor and model
    repo = "Pavang2230/svp-blip-vqa-lora"
    processor = BlipProcessor.from_pretrained(repo)
    model = BlipForQuestionAnswering.from_pretrained(repo).to(device).eval()

    answers = []
    bleus = []
    references = []
    predictions = []

    for idx, row in tqdm(df.iterrows(), total=len(df)):
        question = str(row['Question'])
        expected_answer = str(row['Answer'])
        relative_path = row['path']
        image_path = os.path.join(args.image_dir, relative_path)

        if not os.path.exists(image_path):
            answers.append("image_not_found")
            bleus.append(0.0)
            references.append(expected_answer)
            predictions.append("image_not_found")
            continue

        try:
            image = Image.open(image_path).convert("RGB")
            inputs = processor(image, question, return_tensors="pt").to(device)
            output = model.generate(**inputs)
            answer = processor.decode(output[0], skip_special_tokens=True).strip()
            answer_word = answer.split()[0].lower()  # One-word answer
        except Exception as e:
            answer_word = "error"

        answers.append(answer_word)
        references.append(expected_answer)
        predictions.append(answer_word)

        # BLEU Score
        bleu = compute_bleu(expected_answer, answer_word)
        bleus.append(bleu)

    # Add generated answers and BLEU to DataFrame
    df['generated_answer'] = answers
    df['bleu'] = bleus

    # Compute BERTScore (this can take time)
    P, R, F1 = bert_score(predictions, references, lang="en", verbose=True)
    df['bertscore_f1'] = F1.tolist()

    # Save to CSV
    df.to_csv("results_with_scores.csv", index=False)
    print("\nAverage BLEU:", sum(bleus)/len(bleus))
    print("Average BERTScore F1:", F1.mean().item())

if __name__ == "__main__":
    main()
